package project;

public enum KeyMsg {
	KEY_LEFT, KEY_RIGHT, KEY_SPACE, KEY_A, KEY_S, 
	KEY_LEFT_RELEASED, KEY_RIGHT_RELEASED;
}
