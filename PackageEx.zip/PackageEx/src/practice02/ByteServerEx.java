package practice02;

public class ByteServerEx {
	public static void main(String[] args) {
		int serverPort = 54321;
		new ByteServer(serverPort);
	}
}
