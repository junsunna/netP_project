package practice01;

public class JFrameTest {
	public static void main(String[] args) {
//		new HelloEx2();
		System.out.printf("%02d", 3);
		
	}

}
